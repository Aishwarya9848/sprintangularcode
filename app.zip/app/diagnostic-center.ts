import { Test } from './test';

export class DiagnosticCenter
{
    centerId:number;
    centerName:string;
    contactNumber:string;
    address:string;
    listOfTests:Test[];
}