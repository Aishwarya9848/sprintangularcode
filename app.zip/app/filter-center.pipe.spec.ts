import { FilterCenterPipe } from './filter-center.pipe';

describe('FilterCenterPipe', () => {
  it('create an instance', () => {
    const pipe = new FilterCenterPipe();
    expect(pipe).toBeTruthy();
  });
});
