export class Test
{
    testId:number;
    testName:string;
}