export class Appointment
{
    appointmentId:number;
    userName:number;
    testName:string;
    centerName:string;
    centerId:number;
    approved:boolean;
    
}