import { FilterTestPipe } from './filter-test.pipe';

describe('FilterTestPipe', () => {
  it('create an instance', () => {
    const pipe = new FilterTestPipe();
    expect(pipe).toBeTruthy();
  });
});
