import { Appointment } from './appointment';
export class User {

    userId:number;
    userName:string;
    userPassword:string;
    emailId:string;
    contactNo:number;
    appointment:Appointment[];
  

}
